document.getElementById("prompt-btn").onclick = function() {
    const userInput = window.prompt("Enter a message:");
    alert("You entered: " + userInput);
};