document.getElementById('alert-btn').addEventListener('click', function() {
    alert('Dale que dele');
});