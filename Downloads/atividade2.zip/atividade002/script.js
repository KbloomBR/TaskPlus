document.getElementById("meuBotao").addEventListener("click", function() {
    document.getElementById("meuTexto").textContent = "Estamos em maio e a estação é outono.";
});
